#!/bin/bash
echo "Установка зависимостей..."
pip install -r requirements.txt
echo ""
echo "Запуск Universal Video Downloader..."
echo "Откройте http://localhost:5000"
echo ""
python app.py
