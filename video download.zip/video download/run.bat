@echo off
chcp 65001 >nul

echo Universal Video Downloader
echo ========================
echo.

REM Установка зависимостей
echo Установка зависимостей...
pip install -r requirements.txt
echo.

REM Запуск сервера
echo Запуск сервера...
echo Откройте http://localhost:5000
echo.
python app.py
