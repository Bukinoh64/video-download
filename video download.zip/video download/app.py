from flask import Flask, render_template, request, jsonify, send_file
import yt_dlp
import threading
import uuid
from pathlib import Path
import re
import time

app = Flask(__name__)

downloads_dir = Path('downloads')
downloads_dir.mkdir(exist_ok=True)

trackers = {}

class DownloadCancelled(Exception):
    pass

def make_hook(tracker_id):
    def hook(d):
        tracker = trackers.get(tracker_id)
        if not tracker:
            return
        
        # Check if cancelled
        if tracker.get('status') == 'cancelled':
            raise DownloadCancelled('Download cancelled')
        
        status = d.get('status', '')
        
        if status == 'downloading':
            tracker['status'] = 'downloading'
            downloaded = d.get('downloaded_bytes', 0)
            total = d.get('total_bytes', 0)
            if total > 0:
                tracker['progress'] = (downloaded / total) * 100
                tracker['downloaded'] = downloaded
                tracker['total'] = total
                
        elif status == 'finished':
            tracker['status'] = 'completed'
            tracker['progress'] = 100
            full_filename = d.get('filename', '')
            tracker['filename'] = Path(full_filename).name
            
        elif status == 'error':
            tracker['status'] = 'error'
            tracker['error'] = str(d.get('error', 'Unknown error'))
    
    return hook

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    data = request.get_json()
    url = data.get('url')
    
    if not url:
        return jsonify({'error': 'Введите URL'}), 400
    
    download_id = str(uuid.uuid4())
    
    trackers[download_id] = {
        'status': 'starting',
        'progress': 0,
        'downloaded': 0,
        'total': 0,
        'filename': None,
        'error': None
    }
    
    def download_task():
        opts = {
            'format': 'best[ext=mp4]/best',
            'outtmpl': str(downloads_dir / f'{download_id}%(title)s.%(ext)s').replace('\\', '/'),
            'progress_hooks': [make_hook(download_id)],
            'quiet': True,
        }
        
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                filename = ydl.prepare_filename(info)
                ydl.download([url])
                trackers[download_id]['filename'] = Path(filename).name
                trackers[download_id]['status'] = 'completed'
                trackers[download_id]['progress'] = 100
        except DownloadCancelled:
            trackers[download_id]['status'] = 'cancelled'
            trackers[download_id]['error'] = 'Загрузка отменена'
            # Delete partial file
            try:
                Path(filename).unlink(missing_ok=True)
            except:
                pass
        except Exception as e:
            trackers[download_id]['status'] = 'error'
            trackers[download_id]['error'] = str(e)
    
    threading.Thread(target=download_task, daemon=True).start()
    
    return jsonify({'download_id': download_id})

@app.route('/cancel/<download_id>', methods=['POST'])
def cancel_download(download_id):
    tracker = trackers.get(download_id)
    if not tracker:
        return jsonify({'error': 'Загрузка не найдена'}), 404
    
    if tracker.get('status') not in ['starting', 'downloading']:
        return jsonify({'error': 'Загрузка уже завершена или отменена'}), 400
    
    tracker['status'] = 'cancelled'
    tracker['error'] = 'Загрузка отменена'
    
    return jsonify({'status': 'cancelled'})

@app.route('/status/<download_id>')
def get_status(download_id):
    tracker = trackers.get(download_id)
    if not tracker:
        return jsonify({'status': 'unknown'})
    
    return jsonify({
        'status': tracker.get('status', 'unknown'),
        'progress': tracker.get('progress', 0),
        'downloaded_bytes': tracker.get('downloaded', 0),
        'total_bytes': tracker.get('total', 0),
        'filename': tracker.get('filename'),
        'error': tracker.get('error')
    })

@app.route('/file/<filename>')
def get_file(filename):
    from urllib.parse import unquote
    # Handle URL-encoded filenames
    filename = unquote(filename)
    
    path = downloads_dir / filename
    
    if path.exists():
        return send_file(path, as_attachment=True, download_name=filename)
    
    return jsonify({'error': 'Файл не найден'}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
