"""
VideoSave - Backend Server
Требует: Python 3.8+, Flask, yt-dlp, FFmpeg
"""

import os
import json
import uuid
import threading
from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_cors import CORS
from yt_dlp import YoutubeDL

app = Flask(__name__, static_folder='..')
CORS(app)

# Папка для загрузок
DOWNLOADS_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'downloads')
os.makedirs(DOWNLOADS_FOLDER, exist_ok=True)

# Хранилище прогресса загрузок
download_progress = {}

@app.route('/')
def index():
    """Главная страница"""
    return send_from_directory('..', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    """Раздача статических файлов"""
    return send_from_directory('..', filename)

@app.route('/api/info', methods=['POST'])
def get_video_info():
    """Получение информации о видео"""
    data = request.get_json()
    url = data.get('url', '')
    
    if not url:
        return jsonify({'success': False, 'error': 'URL не указан'}), 400
    
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'format': 'best',
    }
    
    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
        # Формируем список доступных форматов
        formats = []
        if 'formats' in info:
            for f in info['formats']:
                if f.get('vcodec') != 'none':  # Видеоформаты
                    formats.append({
                        'format_id': f.get('format_id'),
                        'ext': f.get('ext'),
                        'height': f.get('height'),
                        'filesize': f.get('filesize') or f.get('filesize_approx', 0),
                        'quality': f.get('quality', 0)
                    })
        
        return jsonify({
            'success': True,
            'title': info.get('title'),
            'thumbnail': info.get('thumbnail'),
            'duration': info.get('duration'),
            'formats': formats[:10],  # Ограничиваем количество форматов
            'platform': detect_platform(url)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/download', methods=['POST'])
def download_video():
    """Начало загрузки видео"""
    data = request.get_json()
    url = data.get('url', '')
    quality = data.get('quality', 'best')
    
    if not url:
        return jsonify({'success': False, 'error': 'URL не указан'}), 400
    
    # Создаём уникальный ID сессии
    session_id = str(uuid.uuid4())
    
    # Настройки загрузки
    ydl_opts = {
        'format': 'bestvideo[height<=' + str(quality) + ']+bestaudio/best[height<=' + str(quality) + ']' if str(quality).isdigit() else 'best',
        'outtmpl': os.path.join(DOWNLOADS_FOLDER, '%(title)s.%(ext)s'),
        'progress_hooks': [lambda d: progress_hook(d, session_id)],
    }
    
    # Запускаем загрузку в фоновом потоке
    thread = threading.Thread(target=start_download, args=(url, session_id, ydl_opts))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'success': True,
        'session_id': session_id,
        'message': 'Загрузка начата'
    })

def start_download(url, session_id, ydl_opts):
    """Фоновая загрузка видео"""
    try:
        download_progress[session_id] = {
            'status': 'downloading',
            'percent': 0,
            'speed': 0,
            'eta': 0,
            'filename': '',
            'download_url': ''
        }
        
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            
        filename = ydl.prepare_filename(info)
        filename = os.path.basename(filename)
        
        download_progress[session_id] = {
            'status': 'completed',
            'percent': 100,
            'speed': 0,
            'eta': 0,
            'filename': filename,
            'download_url': f'/downloads/{filename}',
            'result': {
                'filename': filename,
                'download_url': f'/downloads/{filename}'
            }
        }
        
    except Exception as e:
        download_progress[session_id] = {
            'status': 'error',
            'error': str(e)
        }

def progress_hook(d, session_id):
    """Обработчик прогресса загрузки"""
    if d['status'] == 'downloading':
        total = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
        downloaded = d.get('downloaded_bytes', 0)
        
        percent = int((downloaded / total) * 100) if total > 0 else 0
        speed = d.get('speed', 0)
        eta = d.get('eta', 0)
        
        download_progress[session_id] = {
            'status': 'downloading',
            'percent': percent,
            'speed': int(speed) if speed else 0,
            'eta': int(eta) if eta else 0
        }
    elif d['status'] == 'finished':
        filename = os.path.basename(d['filename'])
        download_progress[session_id] = {
            'status': 'completed',
            'percent': 100,
            'filename': filename,
            'download_url': f'/downloads/{filename}'
        }

@app.route('/api/progress/<session_id>')
def get_progress(session_id):
    """Получение прогресса загрузки"""
    progress = download_progress.get(session_id, {
        'status': 'unknown',
        'percent': 0
    })
    return jsonify(progress)

@app.route('/downloads/<filename>')
def serve_download(filename):
    """Раздача скачанных файлов"""
    return send_from_directory(DOWNLOADS_FOLDER, filename)

@app.route('/api/downloads')
def list_downloads():
    """Список скачанных файлов"""
    files = []
    for f in os.listdir(DOWNLOADS_FOLDER):
        filepath = os.path.join(DOWNLOADS_FOLDER, f)
        if os.path.isfile(filepath):
            files.append({
                'name': f,
                'size': os.path.getsize(filepath),
                'path': f'/downloads/{f}'
            })
    return jsonify(files)

def detect_platform(url):
    """Определение платформы по URL"""
    url_lower = url.lower()
    if 'youtube.com' in url_lower or 'youtu.be' in url_lower:
        return 'YouTube'
    elif 'tiktok.com' in url_lower:
        return 'TikTok'
    elif 'instagram.com' in url_lower:
        return 'Instagram'
    elif 'facebook.com' in url_lower or 'fb.watch' in url_lower:
        return 'Facebook'
    elif 'twitter.com' in url_lower or 'x.com' in url_lower:
        return 'Twitter'
    elif 'vk.com' in url_lower or 'vkvideo.ru' in url_lower:
        return 'VK'
    elif 'twitch.tv' in url_lower:
        return 'Twitch'
    else:
        return 'Unknown'

if __name__ == '__main__':
    print("=" * 50)
    print("  VideoSave Server")
    print("=" * 50)
    print(f"\nОткройте в браузере: http://localhost:5000")
    print(f"Папка загрузок: {DOWNLOADS_FOLDER}")
    print("\nНажмите Ctrl+C для остановки сервера\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
