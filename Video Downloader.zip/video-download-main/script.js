// VideoSave - Interactive Script

// Динамический API_BASE - определяем текущий хост
const API_BASE = window.location.origin;

// Проверка режима запуска
if (window.location.protocol === 'file:') {
    console.warn('⚠️ ВНИМАНИЕ: Приложение запущено через file:// протокол. Для корректной работы нужен HTTP-сервер.');
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.getElementById('downloadForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                alert('Для работы приложения нужен HTTP-сервер.\n\nЗапустите: run.bat\nили выполните: python -m http.server 8000');
            });
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Elements
    const downloadForm = document.getElementById('downloadForm');
    const videoUrlInput = document.getElementById('videoUrl');
    const downloadModal = document.getElementById('downloadModal');
    const modalClose = document.querySelector('.modal-close');
    const qualityOptions = document.getElementById('qualityOptions');
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    // Current video info
    let currentVideoInfo = null;
    let isLoading = false;

    // URL validation patterns
    const supportedPlatforms = [
        /youtube\.com/i,
        /youtu\.be/i,
        /tiktok\.com/i,
        /instagram\.com/i,
        /facebook\.com/i,
        /fb\.watch/i,
        /twitter\.com/i,
        /x\.com/i,
        /vk\.com/i,
        /vkvideo\.ru/i,
        /reddit\.com/i,
        /twitch\.tv/i
    ];

    // Check if URL is supported
    function isSupportedUrl(url) {
        return supportedPlatforms.some(pattern => pattern.test(url));
    }

    // Format file size
    function formatSize(bytes) {
        if (!bytes || bytes === 0) return '~';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
        if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(0) + ' MB';
        return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
    }

    // Format duration
    function formatDuration(seconds) {
        if (!seconds) return '0:00';
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    // Animate input
    function animateInput(element, type) {
        if (type === 'error') {
            element.style.animation = 'shake 0.5s ease-in-out';
            element.style.borderColor = '#ef4444';
            setTimeout(() => {
                element.style.animation = '';
                element.style.borderColor = '';
            }, 500);
        } else if (type === 'success') {
            element.style.borderColor = '#22c55e';
        } else if (type === 'loading') {
            element.style.borderColor = '#3b82f6';
        }
    }

    // Show toast notification
    function showToast(message, type = 'info') {
        const existingToast = document.querySelector('.toast');
        if (existingToast) existingToast.remove();
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <span class="toast-icon">
                ${type === 'success' ? '✓' : type === 'error' ? '✕' : type === 'loading' ? '↻' : 'ℹ'}
            </span>
            <span class="toast-message">${message}</span>
        `;
        
        // Add toast styles dynamically
        if (!document.getElementById('toast-styles')) {
            const style = document.createElement('style');
            style.id = 'toast-styles';
            style.textContent = `
                .toast {
                    position: fixed;
                    bottom: 30px;
                    left: 50%;
                    transform: translateX(-50%);
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    padding: 16px 24px;
                    background: rgba(30, 30, 40, 0.95);
                    backdrop-filter: blur(10px);
                    border: 1px solid var(--border-color);
                    border-radius: 12px;
                    z-index: 3000;
                    animation: slideUp 0.3s ease-out;
                }
                .toast-success { border-color: #22c55e; }
                .toast-error { border-color: #ef4444; }
                .toast-info { border-color: #3b82f6; }
                .toast-loading { border-color: #3b82f6; }
                .toast-loading .toast-icon {
                    animation: spin 1s linear infinite;
                }
                .toast-icon {
                    width: 24px;
                    height: 24px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 50%;
                    font-weight: bold;
                    font-size: 12px;
                }
                .toast-success .toast-icon { background: rgba(34, 197, 94, 0.2); color: #22c55e; }
                .toast-error .toast-icon { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
                .toast-info .toast-icon { background: rgba(59, 130, 246, 0.2); color: #3b82f6; }
                .toast-loading .toast-icon { background: rgba(59, 130, 246, 0.2); color: #3b82f6; }
                .toast-message { color: white; font-weight: 500; }
                @keyframes slideUp {
                    from { opacity: 0; transform: translateX(-50%) translateY(20px); }
                    to { opacity: 1; transform: translateX(-50%) translateY(0); }
                }
                @keyframes shake {
                    0%, 100% { transform: translateX(0); }
                    25% { transform: translateX(-10px); }
                    75% { transform: translateX(10px); }
                }
                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
        document.body.appendChild(toast);
        
        if (type !== 'loading') {
            setTimeout(() => {
                toast.style.animation = 'slideUp 0.3s ease-out reverse';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }
    }

    // Fetch video info from API
    async function fetchVideoInfo(url) {
        try {
            const response = await fetch(`${API_BASE}/api/info`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url, quality: 'best' })
            });
            
            // Check if response is OK
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error fetching video info:', error);
            return { success: false, error: 'Не удалось подключиться к серверу. Убедитесь, что сервер запущен.' };
        }
    }

    // Render quality options
    function renderQualityOptions(info) {
        if (!qualityOptions) return;
        
        qualityOptions.innerHTML = '';
        
        // Add video formats if available
        if (info.formats && info.formats.length > 0) {
            // Sort by height descending
            const sortedFormats = [...info.formats].sort((a, b) => (b.height || 0) - (a.height || 0));
            
            sortedFormats.forEach(format => {
                const btn = document.createElement('button');
                btn.className = 'quality-btn';
                btn.dataset.formatId = format.format_id;
                btn.dataset.quality = format.height;
                btn.innerHTML = `
                    <span class="quality-label">${format.height}p</span>
                    <span class="quality-size">${format.ext.toUpperCase()} • ${formatSize(format.filesize)}</span>
                `;
                qualityOptions.appendChild(btn);
            });
        } else {
            // No formats available - show simple MP3/MP4 options
            const defaultOptions = [
                { quality: 'mp4', label: '🎬 MP4 (Видео)' },
                { quality: 'mp3', label: '🎵 MP3 (Аудио)' }
            ];
            
            defaultOptions.forEach(opt => {
                const btn = document.createElement('button');
                btn.className = 'quality-btn';
                btn.dataset.quality = opt.quality;
                btn.innerHTML = `
                    <span class="quality-label">${opt.label}</span>
                    <span class="quality-size">${opt.quality === 'mp4' ? 'Видео' : 'Аудио'}</span>
                `;
                qualityOptions.appendChild(btn);
            });
        }
        
        // Add event listeners
        qualityOptions.querySelectorAll('.quality-btn').forEach(btn => {
            btn.addEventListener('click', () => handleDownload(btn.dataset));
        });
    }

    // Handle download - saves to downloads folder
    async function handleDownload(formatData) {
        const url = videoUrlInput.value.trim();
        const quality = formatData.quality;
        // Показываем модальное окно с прогрессом
        downloadModal.classList.add('active');
        const qualityOptionsEl = document.getElementById('qualityOptions');
        const progressEl = document.getElementById('downloadProgress');
        const progressPercent = document.getElementById('progressPercent');
        const progressFill = document.getElementById('progressFill');
        const progressSpeed = document.getElementById('progressSpeed');
        const progressEta = document.getElementById('progressEta');
        const modalTitle = downloadModal.querySelector('.modal-header h3');
        
        console.log('[Download] Elements found:', {
            qualityOptionsEl: !!qualityOptionsEl,
            progressEl: !!progressEl,
            progressPercent: !!progressPercent,
            progressFill: !!progressFill,
            progressSpeed: !!progressSpeed,
            progressEta: !!progressEta
        });
        qualityOptionsEl.style.display = 'none';
        progressEl.style.display = 'block';
        modalTitle.textContent = 'Загрузка видео';
        
        // Сбрасываем прогресс
        progressFill.style.width = '0%';
        progressPercent.textContent = '0%';
        progressSpeed.textContent = '';
        progressEta.textContent = '';
        
        try {
            // Запускаем загрузку
            const response = await fetch(`${API_BASE}/api/download`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    url, 
                    quality
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.error || 'Ошибка загрузки');
            }
            
            const sessionId = data.session_id;
            
            // Опрашиваем прогресс
            const pollProgress = async () => {
                try {
                    const progressResponse = await fetch(`${API_BASE}/api/progress/${sessionId}`);
                    if (!progressResponse.ok) {
                        console.error('Progress response not OK:', progressResponse.status);
                        setTimeout(pollProgress, 200);
                        return;
                    }
                    const progressData = await progressResponse.json();
                    
                    // Обновляем UI - ВСЕГДА, независимо от статуса
                    const percent = progressData.percent || 0;
                    if (progressFill) progressFill.style.width = `${percent}%`;
                    if (progressPercent) progressPercent.textContent = `${percent}%`;
                    
                    if (progressData.speed && progressSpeed) {
                        // Форматируем скорость
                        let speed = progressData.speed;
                        try {
                            const speedNum = parseFloat(speed);
                            if (!isNaN(speedNum)) {
                                const speedMbps = (speedNum / 1024 / 1024).toFixed(1);
                                progressSpeed.textContent = `Скорость: ${speedMbps} MB/s`;
                            } else {
                                progressSpeed.textContent = `Скорость: ${speed}`;
                            }
                        } catch(e) {
                            progressSpeed.textContent = `Скорость: ${speed}`;
                        }
                    }
                    if (progressData.eta && progressEta) {
                        let eta = progressData.eta;
                        try {
                            const etaNum = parseInt(eta);
                            if (!isNaN(etaNum)) {
                                progressEta.textContent = `Осталось: ~${etaNum} сек`;
                            } else {
                                progressEta.textContent = '';
                            }
                        } catch(e) {
                            progressEta.textContent = '';
                        }
                    }
                    
                    // Проверяем статус завершения
                    if (progressData.status === 'completed' || progressData.status === 'finished') {
                        // Загрузка завершена
                        if (progressFill) progressFill.style.width = '100%';
                        if (progressPercent) progressPercent.textContent = '100%';
                        if (progressEta) progressEta.textContent = 'Готово!';
                        if (progressSpeed) progressSpeed.textContent = '';
                        
                        // Автоматически скачиваем файл на устройство
                        if (progressData.result && progressData.result.download_url) {
                            const downloadLink = `${API_BASE}${progressData.result.download_url}`;
                            const filename = progressData.result.filename;
                            
                            const link = document.createElement('a');
                            link.href = downloadLink;
                            link.download = filename;
                            link.style.display = 'none';
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                        }
                        
                        // Показываем уведомление об успехе
                        showToast('Видео успешно скачано!', 'success');
                        
                        // Закрываем модальное окно и сбрасываем форму
                        setTimeout(() => {
                            downloadModal.classList.remove('active');
                            // Сбрасываем вид модального окна
                            if (qualityOptionsEl) qualityOptionsEl.style.display = '';
                            if (progressEl) progressEl.style.display = 'none';
                            if (modalTitle) modalTitle.textContent = 'Выберите качество';
                        }, 1500);
                        return;
                    } else if (progressData.status === 'error') {
                        showToast(progressData.error || 'Ошибка при скачивании', 'error');
                        downloadModal.classList.remove('active');
                        return;
                    }
                    
                    // Продолжаем опрос для любого статуса
                    setTimeout(pollProgress, 200);
                    
                } catch (e) {
                    console.error('Progress error:', e);
                    setTimeout(pollProgress, 200);
                }
            };
            
            // Начинаем опрос прогресса
            setTimeout(pollProgress, 200);
            
        } catch (error) {
            console.error('Download error:', error);
            showToast(error.message || 'Ошибка при скачивании. Убедитесь, что сервер запущен.', 'error');
            downloadModal.classList.remove('active');
        }
    }

    // Show download location in modal
    function showDownloadLocation(file, folder) {
        downloadModal.classList.add('active');
        const modalContent = downloadModal.querySelector('.modal-content');
        const modalHeader = downloadModal.querySelector('.modal-header');
        
        modalHeader.innerHTML = '<h3>Файл скачан!</h3>';
        
        const qualityOptionsEl = document.getElementById('qualityOptions');
        if (qualityOptionsEl) {
            qualityOptionsEl.innerHTML = `
                <div class="download-success">
                    <div class="success-icon">✓</div>
                    <p class="file-name">${file.name}</p>
                    <p class="file-size">${file.size_formatted}</p>
                    <div class="file-path">
                        <span>Папка:</span>
                        <code>${folder}</code>
                    </div>
                </div>
            `;
        }
        
        // Add styles for download success
        addDownloadSuccessStyles();
    }

    // Add styles for download success
    function addDownloadSuccessStyles() {
        if (document.getElementById('download-success-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'download-success-styles';
        style.textContent = `
            .download-success {
                text-align: center;
                padding: 20px;
            }
            .success-icon {
                width: 60px;
                height: 60px;
                background: rgba(34, 197, 94, 0.2);
                color: #22c55e;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 30px;
                margin: 0 auto 20px;
            }
            .file-name {
                font-size: 1.1rem;
                font-weight: 600;
                margin-bottom: 8px;
                word-break: break-all;
            }
            .file-size {
                color: #22c55e;
                font-weight: 500;
                margin-bottom: 20px;
            }
            .file-path {
                background: rgba(0, 0, 0, 0.3);
                padding: 12px;
                border-radius: 8px;
                font-size: 0.85rem;
            }
            .file-path span {
                color: #888;
                display: block;
                margin-bottom: 4px;
            }
            .file-path code {
                color: #6366f1;
                word-break: break-all;
            }
        `;
        document.head.appendChild(style);
    }

    // Show download link in modal
    function showDownloadLink(filename, downloadLink) {
        downloadModal.classList.add('active');
        const modalHeader = downloadModal.querySelector('.modal-header');
        
        modalHeader.innerHTML = '<h3>Файл готов к скачиванию!</h3>';
        
        const qualityOptionsEl = document.getElementById('qualityOptions');
        if (qualityOptionsEl) {
            qualityOptionsEl.innerHTML = `
                <div class="download-success">
                    <div class="success-icon">⬇</div>
                    <p class="file-name">${filename}</p>
                    <p class="download-hint">Файл автоматически скачивается на ваше устройство</p>
                    <div class="download-link-box">
                        <span>Ссылка для скачивания:</span>
                        <a href="${downloadLink}" download class="direct-download-btn">
                            Скачать файл
                        </a>
                    </div>
                </div>
            `;
        }
        
        // Add styles for download link
        addDownloadLinkStyles();
    }

    // Add styles for download link
    function addDownloadLinkStyles() {
        if (document.getElementById('download-link-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'download-link-styles';
        style.textContent = `
            .download-hint {
                color: #22c55e;
                font-weight: 500;
                margin-bottom: 20px;
            }
            .download-link-box {
                background: rgba(0, 0, 0, 0.3);
                padding: 16px;
                border-radius: 8px;
                font-size: 0.85rem;
            }
            .download-link-box span {
                color: #888;
                display: block;
                margin-bottom: 12px;
            }
            .direct-download-btn {
                display: inline-block;
                background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
                color: white;
                padding: 12px 24px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .direct-download-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 20px rgba(99, 102, 241, 0.4);
            }
        `;
        document.head.appendChild(style);
    }

    // Handle form submission
    if (downloadForm) {
        downloadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const url = videoUrlInput.value.trim();
            
            if (!url) {
                animateInput(videoUrlInput, 'error');
                showToast('Пожалуйста, введите URL видео', 'error');
                return;
            }
            
            if (!isSupportedUrl(url)) {
                animateInput(videoUrlInput, 'error');
                showToast('Эта платформа не поддерживается', 'error');
                return;
            }
            
            // Сразу начинаем загрузку в MP4 качестве
            isLoading = true;
            animateInput(videoUrlInput, 'loading');
            showToast('Начинаем загрузку...', 'loading');
            
            // Сразу вызываем handleDownload с MP4
            await handleDownload({ quality: 'mp4' });
            
            isLoading = false;
        });
    }

    // Close modal
    if (modalClose) {
        modalClose.addEventListener('click', () => {
            downloadModal.classList.remove('active');
        });
        
        // Close on outside click
        downloadModal.addEventListener('click', (e) => {
            if (e.target === downloadModal) {
                downloadModal.classList.remove('active');
            }
        });
    }

    // Mobile menu toggle
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            menuToggle.classList.toggle('active');
        });
        
        // Close menu on link click
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                menuToggle.classList.remove('active');
            });
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Header scroll effect
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll > 100) {
            header.style.background = 'rgba(10, 10, 15, 0.95)';
            header.style.boxShadow = '0 4px 30px rgba(0, 0, 0, 0.3)';
        } else {
            header.style.background = 'rgba(10, 10, 15, 0.8)';
            header.style.boxShadow = 'none';
        }
    });

    // Add parallax effect to gradient orbs
    const orbs = document.querySelectorAll('.gradient-orb');
    
    document.addEventListener('mousemove', (e) => {
        const x = (window.innerWidth / 2 - e.clientX) / 50;
        const y = (window.innerHeight / 2 - e.clientY) / 50;
        
        orbs.forEach((orb, index) => {
            const speed = (index + 1) * 0.5;
            orb.style.transform = `translate(${x * speed}px, ${y * speed}px)`;
        });
    });

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observe elements
    document.querySelectorAll('.feature-card, .step, .stat-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease-out';
        observer.observe(el);
    });

    // Add animation class styles
    if (!document.getElementById('anim-styles')) {
        const animStyle = document.createElement('style');
        animStyle.id = 'anim-styles';
        animStyle.textContent = `
            .animate-in {
                opacity: 1 !important;
                transform: translateY(0) !important;
            }
            .nav-links.active {
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: rgba(10, 10, 15, 0.98);
                padding: 20px;
                gap: 0;
                border-bottom: 1px solid var(--border-color);
            }
            .menu-toggle.active span:nth-child(1) {
                transform: rotate(45deg) translate(5px, 5px);
            }
            .menu-toggle.active span:nth-child(2) {
                opacity: 0;
            }
            .menu-toggle.active span:nth-child(3) {
                transform: rotate(-45deg) translate(5px, -5px);
            }
        `;
        document.head.appendChild(animStyle);
    }

    // Input focus effects
    if (videoUrlInput) {
        videoUrlInput.addEventListener('input', () => {
            videoUrlInput.style.borderColor = '';
        });
    }

    // CTA form
    const ctaForm = document.querySelector('.cta-form');
    if (ctaForm) {
        ctaForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const input = ctaForm.querySelector('input');
            if (input && input.value.trim()) {
                if (isSupportedUrl(input.value.trim())) {
                    videoUrlInput.value = input.value.trim();
                    downloadForm.dispatchEvent(new Event('submit'));
                } else {
                    showToast('Эта платформа не поддерживается', 'error');
                }
                input.value = '';
            }
        });
    }
});
