# VideoSave - Скачивай видео легко

Простой веб-сервис для скачивания видео с популярных сайтов.

## Возможности

- Скачивать видео с YouTube, TikTok, Twitter, Instagram, Facebook, VK и других сайтов
- Выбор качества видео (до 4K)
- Извлечение аудио (MP3)
- История загрузок
- Отмена загрузки во время процесса

## Требования

- Python 3.8+
- FFmpeg (для конвертации видео)

### Установка FFmpeg:

- **Windows**: `winget install ffmpeg` или скачайте с ffmpeg.org
- **Linux**: `sudo apt install ffmpeg`
- **Mac**: `brew install ffmpeg`

## Установка

1. Установите FFmpeg (см. выше)

2. Установите зависимости:
   ```
   pip install -r videosave/requirements.txt
   ```

## Запуск

### Windows:
Запустите файл `run.bat`

### Linux/Mac:
```bash
cd videosave
pip install -r requirements.txt
python app.py
```

После запуска откройте **http://localhost:5000** в браузере.

## Использование

1. Вставьте ссылку на видео в поле ввода
2. Нажмите "Скачать"
3. Выберите качество видео
4. Дождитесь завершения загрузки
5. Файл сохранится в папку `videosave/downloads/`

## Поддерживаемые платформы

- YouTube / YouTube Music
- TikTok
- Instagram
- Facebook
- Twitter / X
- VK
- Reddit
- Twitch
- И многие другие...

## Структура проекта

```
video-download-main/
├── index.html          # Главная страница
├── styles.css          # Стили
├── script.js           # JavaScript
├── run.bat             # Запуск (Windows)
├── README.md          # Документация
└── videosave/
    ├── app.py          # Flask сервер
    ├── requirements.txt # Зависимости
    └── downloads/      # Папка для загрузок
```
